library(testthat)
library(tsgrf)

# This treats warnings as errors
options(warn = 2)
test_check("tsgrf")
